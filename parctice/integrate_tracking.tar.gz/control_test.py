import serial 
import numpy as np 

def send_msg(byte_array):
	ser = serial.Serial('/dev/ttyUSB0',115200)
	ser.write(byte_array)
	ser.close()

def send_turret(pitch,yaw):
	data_pack = b'\xab\x55'

	data = np.int16([pitch,yaw])
	buff = data.tobytes()

	data_pack += buff[1] + buff[0] + buff[3] + buff[2]
	check_sum = ord(buff[0]) + ord(buff[1]) + ord(buff[2]) + ord(buff[3])
	check_sum = np.int16([check_sum]).tobytes()[0]
	data_pack += check_sum + b'\xff'
	return data_pack

def send_order(pitch,yaw):
	data = send_turret(pitch,yaw)
	send_msg(data)
