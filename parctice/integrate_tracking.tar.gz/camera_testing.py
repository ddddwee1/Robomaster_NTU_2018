import tensorflow as tf
import graph
import model as M
import numpy as np 
import cv2
import Functions as F

def draw(img,b,inds,c_veri,wait=0,show=True):
	x = 128
	y = 128
	img = img.copy()
	for k in range(len(c_veri)):
		if c_veri[k]>0:
			ind = inds[k]
			i = ind//16
			j = ind%16
			x = int(b[i][j][0])+j*16+8
			y = int(b[i][j][1])+i*16+8
			w = int(b[i][j][2])
			h = int(b[i][j][3])
			x = x-w
			y = y-h
			cv2.rectangle(img,(x-w,y-h),(x+w,y+h),(0,255,0),2)
			# print('draw')
	if show:
		cv2.imshow('RPN+VERI',img)
		cv2.waitKey(wait)
	# cv2.destroyAllWindows()
	return x,y

RPNholders, veriholders, RPNlosses, verilosses, train_steps, RPNcb, vericb, feature_map = graph.build_graph(False)
sess = tf.Session()
M.loadSess('./model_VERI/',sess)

def test_veri(img_in,imgholder,conf,bias,croppedholder,veri_conf):
	img = cv2.resize(img_in,(256,256))
	c,b = sess.run([conf,bias],feed_dict={imgholder:[img]})
	cropped_imgs, inds = F.crop_original_test(img,c[0],b[0])
	c_veri = sess.run(veri_conf,feed_dict={croppedholder:cropped_imgs})
	x,y = draw(img,b[0],inds,c_veri[0],1)
	return x,y

def eval(img):
	return test_veri(img,RPNholders[0],RPNcb[0],RPNcb[1],veriholders[0],vericb[0])
