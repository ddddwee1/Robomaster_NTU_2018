import cv2 
import numpy as np 
import camera_testing as net
import control_test as ctrl

cap = cv2.VideoCapture(1)
for i in range(1000):
	ret,frame = cap.read()
	x,y = net.eval(frame)
	print x,y
	x = x - 128
	y = 128 -y
	#print x,y
	ctrl.send_order(x,y)

#ctrl.send_order(100,-100)
